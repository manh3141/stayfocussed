gTTS-token
====

**gTTS-token** (Google Text to Speech token): A python implementation of the token validation of Google Translate

[![Build Status](https://travis-ci.org/Boudewijn26/gTTS-token.svg?branch=master)](https://travis-ci.org/Boudewijn26/gTTS-token)

Install
-------

    pip install gTTS-token

Description
-------

Google Translate requires a tk param when making a request to its translate API. This project provides an implementation for that algorithm in Python.

