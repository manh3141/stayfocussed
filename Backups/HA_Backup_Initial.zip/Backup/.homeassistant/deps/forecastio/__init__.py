from forecastio.api import load_forecast, manual
