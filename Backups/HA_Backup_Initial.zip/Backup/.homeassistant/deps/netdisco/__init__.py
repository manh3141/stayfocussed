"""Module to scan the network using uPnP and mDNS for devices and services."""
